create database PG_Accomodation;
use PG_Accomodation;

show tables;
drop database PG_Accomodation;

select * from user;

INSERT INTO user (username, email, password, user_role) VALUES ('Alice', 'alice@example.com', 'securepassword', 'TENANT');

INSERT INTO tenant (user_id, tenant_name, tenant_email, tenant_phone, tenant_address) VALUES (1, 'Alice Smith', 'alice.tenant@example.com', '1234567890', '123 Main Street');

select * from user;
select * from tenant;

delete from user where user_id = 4;
delete from tenant where tenant_id = 3;

delete from tenant where pg_id = 202;

select * from owner;
select * from pg;

delete from pg where pgid = 152;

desc tenant;
desc owner;

INSERT INTO user (username, email, password, user_role) VALUES ('Pranjal', 'pranjal@example.com', 'securepassword', 'OWNER');
INSERT INTO owner (user_id, owner_name,owner_email, owner_phone, owner_address) VALUES (2, 'Pranjal', 'pranjal@example.com', '1234567890', '123 Main Street');








