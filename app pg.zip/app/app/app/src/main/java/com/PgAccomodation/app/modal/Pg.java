package com.PgAccomodation.app.modal;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Pg {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int pgid;

    private String pgname;

    private String address;

    private String location;

    private int totalrooms;

    private int availableSeats;

    private int rentPerflat;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private Owner owner;

    @OneToMany(mappedBy = "pg")
    private List<Tenant> tenants = new ArrayList<>();

    public Pg() {}

    public Pg(int pgid, String pgname, String address, String location, int totalrooms, int availableSeats, int rentPerflat, Owner owner, List<Tenant> tenants) {
        this.pgid = pgid;
        this.pgname = pgname;
        this.address = address;
        this.location = location;
        this.totalrooms = totalrooms;
        this.availableSeats = availableSeats;
        this.rentPerflat = rentPerflat;
        this.owner = owner;
        this.tenants = tenants;
    }

    public int getPgid() {
        return pgid;
    }

    public void setPgid(int pgid) {
        this.pgid = pgid;
    }

    public String getPgname() {
        return pgname;
    }

    public void setPgname(String pgname) {
        this.pgname = pgname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getTotalrooms() {
        return totalrooms;
    }

    public void setTotalrooms(int totalrooms) {
        this.totalrooms = totalrooms;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public int getRentPerflat() {
        return rentPerflat;
    }

    public void setRentPerflat(int rentPerflat) {
        this.rentPerflat = rentPerflat;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public List<Tenant> getTenants() {
        return tenants;
    }

    public void setTenants(List<Tenant> tenants) {
        this.tenants = tenants;
    }
}
