package com.PgAccomodation.app.Repo;

import com.PgAccomodation.app.modal.Tenant;
import com.PgAccomodation.app.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TenantRepository extends JpaRepository<Tenant , Integer> {

    Optional<Tenant> findByUser(User user);
}
