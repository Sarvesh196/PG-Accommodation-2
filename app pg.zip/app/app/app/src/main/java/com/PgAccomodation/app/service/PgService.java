package com.PgAccomodation.app.service;

import com.PgAccomodation.app.Exception.ResouceAlreadyExistException;
import com.PgAccomodation.app.Exception.ResourceNotFoundException;
import com.PgAccomodation.app.Repo.OwnerRepository;
import com.PgAccomodation.app.Repo.PgRepo;
import com.PgAccomodation.app.dto.*;
import com.PgAccomodation.app.modal.Owner;
import com.PgAccomodation.app.modal.Pg;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PgService {

    PgRepo pgRepo;
    OwnerRepository ownerRepository;


    public PgService(PgRepo pgRepo, OwnerRepository ownerRepository) {
        this.pgRepo = pgRepo;
        this.ownerRepository = ownerRepository;
    }

    public ResponseEntity<?> registerPg(Pg pg) {
        try {

            int ownerId = Math.toIntExact(pg.getOwner().getOwnerId());
            Optional<Owner> ownerOptional = ownerRepository.findById(ownerId);

            if (ownerOptional.isEmpty()) {
                throw new ResourceNotFoundException("Owner not found with ID: " + ownerId);
            }

            Owner owner = ownerOptional.get();
            pg.setOwner(owner);


            Optional<Pg> existingPgByName = pgRepo.findByPgnameAndOwner(pg.getPgname(), owner);
            Optional<Pg> existingPgByAddress = pgRepo.findByAddressAndOwner(pg.getAddress(), owner);

            if (existingPgByName.isPresent() || existingPgByAddress.isPresent()) {
                throw new ResouceAlreadyExistException("A PG with the same name or address already exists for this owner.");
            }

            Pg savedPg = pgRepo.save(pg);

            OwnerDTO ownerDTO = new OwnerDTO(
                    Math.toIntExact(owner.getOwnerId()),
                    owner.getOwnerName(),
                    owner.getOwnerEmail(),
                    owner.getOwnerPhone()
            );

            List<PgDto> pgDtoList = owner.getOwnerPgs().stream()
                    .map(p -> new PgDto(
                            p.getPgid(),
                            p.getPgname(),
                            p.getAddress(),
                            p.getLocation(),
                            p.getTotalrooms(),
                            p.getAvailableSeats(),
                            p.getRentPerflat()
                    ))
                    .collect(Collectors.toList());

            RegisterPGResponseDto pgResponse = new RegisterPGResponseDto(
                    savedPg.getPgid(),
                    savedPg.getPgname(),
                    savedPg.getAddress(),
                    savedPg.getLocation(),
                    savedPg.getTotalrooms(),
                    savedPg.getAvailableSeats(),
                    savedPg.getRentPerflat(),
                    ownerDTO,
                    pgDtoList
            );

            SuccessResponse<RegisterPGResponseDto> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PG registered successfully",
                    pgResponse
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {

            System.out.println(e);
            throw e;

//            e.printStackTrace();


//            ErrorResponse errorResponse = new ErrorResponse(
//                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
//                    e.getMessage(),
//                    e.getStackTrace()
//            );
//            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getPgByCityName(String city){
        try{

            List<Pg> pgList = pgRepo.findByLocationIgnoreCase(city);

            if (pgList.isEmpty()) {
                throw new ResourceNotFoundException("No PGs found in city : " + city);
            }


            List<PgDto> pgDtoList = pgList.stream()
                    .map(pg -> {
                        Owner owner = pg.getOwner();
                        OwnerDTO ownerDTO = new OwnerDTO(
                                Math.toIntExact(owner.getOwnerId()),
                                owner.getOwnerName(),
                                owner.getOwnerEmail(),
                                owner.getOwnerPhone()
                        );

                        return new PgDto(
                                pg.getPgid(),
                                pg.getPgname(),
                                pg.getAddress(),
                                pg.getLocation(),
                                pg.getTotalrooms(),
                                pg.getAvailableSeats(),
                                pg.getRentPerflat()
                        );
                    })
                    .collect(Collectors.toList());

            SuccessResponse<List<PgDto>> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PGs retrieved successfully for city: " + city,
                    pgDtoList
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
//            ErrorResponse errorResponse = new ErrorResponse(
//                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
//                    e.getMessage(),
//                  e.getStackTrace().getClass().toString()
//            );
//            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getPgById(int pgid) {
        try {
            Optional<Pg> pgOptional = pgRepo.findById(pgid);

            if (pgOptional.isEmpty()) {
                throw new ResourceNotFoundException("PG not found with ID: " + pgid);
            }


            Pg pg = pgOptional.get();
            Owner owner = pg.getOwner();

            OwnerDTO ownerDTO = new OwnerDTO(
                    Math.toIntExact(owner.getOwnerId()),
                    owner.getOwnerName(),
                    owner.getOwnerEmail(),
                    owner.getOwnerPhone()
            );
                RegisterPGResponseDto pgResponse = new RegisterPGResponseDto(
                        pg.getPgid(),
                        pg.getPgname(),
                        pg.getAddress(),
                        pg.getLocation(),
                        pg.getTotalrooms(),
                        pg.getAvailableSeats(),
                        pg.getRentPerflat(),
                        ownerDTO,
                        new ArrayList<>()
                );

            SuccessResponse<RegisterPGResponseDto> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PG retrieved successfully",
                    pgResponse
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
        }
    }

    public ResponseEntity<?> getPgByLocality(String locality) {
        try {

            List<Pg> pgs = pgRepo.findAll();

            List<Pg> filteredPgs = pgs.stream()
                    .filter(pg -> pg.getAddress() != null &&
                            pg.getAddress().toLowerCase().contains(locality.toLowerCase()))
                    .collect(Collectors.toList());

            if (filteredPgs.isEmpty()) {
                throw new ResourceNotFoundException("No PGs found in locality: " + locality );
            }

            List<PgDto> pgDtoList = filteredPgs.stream()
                    .map(pg -> {
                        Owner owner = pg.getOwner();
                        OwnerDTO ownerDTO = new OwnerDTO(
                                Math.toIntExact(owner.getOwnerId()),
                                owner.getOwnerName(),
                                owner.getOwnerEmail(),
                                owner.getOwnerPhone()
                        );

                        return new PgDto(
                                pg.getPgid(),
                                pg.getPgname(),
                                pg.getAddress(),
                                pg.getLocation(),
                                pg.getTotalrooms(),
                                pg.getAvailableSeats(),
                                pg.getRentPerflat()
                        );

                    })
                    .collect(Collectors.toList());

            SuccessResponse<List<PgDto>> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PGs retrieved successfully for locality: " + locality,
                    pgDtoList
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
        }
    }

    public ResponseEntity<?> getPgOwnerDetails(int pgId) {
        try {

            Optional<Pg> ownerOptional = pgRepo.findById(pgId);

            if (ownerOptional.isEmpty()) {
                throw new ResourceNotFoundException("Owner not found with ID: " + pgId);
            }

            Owner owner = ownerOptional.get().getOwner();

            OwnerDTO ownerDTO = new OwnerDTO(
                    Math.toIntExact(owner.getOwnerId()),
                    owner.getOwnerName(),
                    owner.getOwnerEmail(),
                    owner.getOwnerPhone()
            );

            SuccessResponse<OwnerDTO> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "Owner Details Fetched successfully",
                    ownerDTO
            );
            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
//            ErrorResponse errorResponse = new ErrorResponse(
//                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
//                    e.getMessage(),
//                    Arrays.toString(e.getStackTrace())
//            );
//            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getAllPgDetailsByOwner(int ownerId){
       try {
           List<Pg> filteredPgs = pgRepo.findAll().stream()
                   .filter(pg -> pg.getOwner() != null &&
                           pg.getOwner().getOwnerId().equals((long) ownerId))
                   .collect(Collectors.toList());

           if (filteredPgs.isEmpty()) {
               throw new ResourceNotFoundException("No PGs found for Owner ID: " + ownerId);
           }

           Owner owner = filteredPgs.get(0).getOwner();

           List<PgDto> pgDtoList = filteredPgs.stream()
                   .map(pg -> new PgDto(
                           pg.getPgid(),
                           pg.getPgname(),
                           pg.getAddress(),
                           pg.getLocation(),
                           pg.getTotalrooms(),
                           pg.getAvailableSeats(),
                           pg.getRentPerflat()
                   ))
                   .collect(Collectors.toList());

           SuccessResponse<List<PgDto>> successResponse = new SuccessResponse<>(
                   HttpStatus.OK.value(),
                   "PGs retrieved successfully for Owner: " + owner.getOwnerName(),
                   pgDtoList
           );
           return ResponseEntity.ok(successResponse);
       }
       catch (Exception e) {
           System.out.println(e);
           throw e;
       }
    }

    // update Pg Details
    public ResponseEntity<?> updatePgDetails(int pgId, Pg pg) {
        try {
            Optional<Pg> pgOptional = pgRepo.findById(pgId);

            if (pgOptional.isEmpty()) {
                throw new ResourceNotFoundException("PG not found with ID: " + pgId);
            }

            Pg existingPg = pgOptional.get();

            existingPg.setPgname(pg.getPgname());
            existingPg.setAddress(pg.getAddress());
            existingPg.setLocation(pg.getLocation());
            existingPg.setTotalrooms(pg.getTotalrooms());
            existingPg.setAvailableSeats(pg.getAvailableSeats());
            existingPg.setRentPerflat(pg.getRentPerflat());

            if (pg.getOwner() != null) {
                existingPg.setOwner(pg.getOwner());
            }

            if (pg.getTenants() != null && !pg.getTenants().isEmpty()) {
                existingPg.setTenants(pg.getTenants());
            }

            Pg updatedPg = pgRepo.save(existingPg);

            PgDto pgDto =  new PgDto(
                    pg.getPgid(),
                    pg.getPgname(),
                    pg.getAddress(),
                    pg.getLocation(),
                    pg.getTotalrooms(),
                    pg.getAvailableSeats(),
                    pg.getRentPerflat()
            );

            SuccessResponse<PgDto> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PG Details Updated successfully with Id : " + pg.getPgid(),
                    pgDto
            );
            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
        }
    }

    // delete pg Details
    public ResponseEntity<?> deletePgDetails(int id){
        try{
            Optional<Pg> pgOptional = pgRepo.findById(id);

            if (pgOptional.isEmpty()) {
                throw new ResourceNotFoundException("PG not found with ID: " + id);
            }

            Pg pg = pgOptional.get();

            pgRepo.delete(pg);

            SuccessResponse<String> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "PG Details Deleted successfully with Id : " + pg.getPgid(),
                    pg.getPgname()
            );
            return ResponseEntity.ok(successResponse);

        }catch (Exception e){
            System.out.println(e);
            throw e;
        }
    }

}