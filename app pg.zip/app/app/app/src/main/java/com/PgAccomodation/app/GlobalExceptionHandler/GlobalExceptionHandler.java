package com.PgAccomodation.app.GlobalExceptionHandler;

import com.PgAccomodation.app.Exception.ResouceAlreadyExistException;
import com.PgAccomodation.app.Exception.ResourceNotFoundException;
import com.PgAccomodation.app.dto.ErrorResponse;  // <- Use your DTO
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Arrays;

@ControllerAdvice
public class GlobalExceptionHandler {

    public String[] getStackTrace(StackTraceElement[] stackTraceElements) {
        int limit = Math.min(3, stackTraceElements.length); // take first 3 elements
        String[] result = new String[limit];

        for (int i = 0; i < limit; i++) {
            StackTraceElement element = stackTraceElements[i];
            result[i] = element.getClassName() + "." +
                    element.getMethodName() + "(" +
                    element.getFileName() + ":" +
                    element.getLineNumber() + ")";
        }

        return result;
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFound(ResourceNotFoundException ex) {

        ErrorResponse errorResponse = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                getStackTrace(ex.getStackTrace())
        );

        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ResouceAlreadyExistException.class)
    public ResponseEntity<ErrorResponse> handleAlreadyExist(ResouceAlreadyExistException ex) {
        ErrorResponse errorResponse = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                getStackTrace(ex.getStackTrace())
        );

        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                ex.getMessage(),
                getStackTrace(ex.getStackTrace())
        );

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
