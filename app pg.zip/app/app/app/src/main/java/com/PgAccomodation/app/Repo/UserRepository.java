package com.PgAccomodation.app.Repo;

import com.PgAccomodation.app.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
}
