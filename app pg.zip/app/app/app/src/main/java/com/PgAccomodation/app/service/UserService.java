package com.PgAccomodation.app.service;

import com.PgAccomodation.app.Repo.OwnerRepository;
import com.PgAccomodation.app.Repo.TenantRepository;
import com.PgAccomodation.app.Repo.UserRepository;
import com.PgAccomodation.app.dto.ErrorResponse;
import com.PgAccomodation.app.dto.SuccessResponse;
import com.PgAccomodation.app.modal.Owner;
import com.PgAccomodation.app.modal.Tenant;
import com.PgAccomodation.app.modal.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Arrays;

@Service
public class UserService {

    UserRepository userRepository;
    TenantRepository tenantRepository;
    OwnerRepository ownerRepository;

    public UserService(UserRepository userRepository ,TenantRepository tenantRepository , OwnerRepository ownerRepository ){
        this.userRepository = userRepository;
        this.tenantRepository = tenantRepository;
        this.ownerRepository = ownerRepository;
    }


    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {

            User savedUser = userRepository.save(user);


            if ("TENANT".equalsIgnoreCase(user.getUserRole())) {
                Tenant tenant = new Tenant();
                tenant.setTenantName(user.getUsername());
                tenant.setTenantEmail(user.getEmail());
                tenant.setTenantPhone(user.getPhoneNumber());
                tenant.setTenantAddress(user.getAddress());
                tenant.setUser(savedUser);
                tenantRepository.save(tenant);

            } else if ("OWNER".equalsIgnoreCase(user.getUserRole())) {
                Owner owner = new Owner();
                owner.setOwnerName(user.getUsername());
                owner.setOwnerEmail(user.getEmail());
                owner.setOwnerPhone(user.getPhoneNumber());
                owner.setOwnerAddress(user.getAddress());
                owner.setUser(savedUser);
                ownerRepository.save(owner);
            } else {
                throw new IllegalArgumentException("Invalid role: " + user.getUserRole());
            }

            SuccessResponse<String> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "Hello " + user.getUsername(),
                    "User registered successfully as " + user.getUserRole()
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
        }
    }

}
