package com.PgAccomodation.app.Repo;

import com.PgAccomodation.app.modal.Owner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OwnerRepository extends JpaRepository<Owner , Integer> {
}
