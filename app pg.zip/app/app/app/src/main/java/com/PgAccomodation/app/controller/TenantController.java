package com.PgAccomodation.app.controller;

import com.PgAccomodation.app.service.TenantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/tenant")
public class TenantController {

    @Autowired
    TenantService tenantService;

    @GetMapping("/registerTenant")
    public ResponseEntity<?> registerToPg (@RequestParam("userId") String userid , @RequestParam("pgId")String PgId){
        return tenantService.registerTenantToPg(userid , PgId);
    }

}
