package com.PgAccomodation.app.service;

import com.PgAccomodation.app.Exception.ResourceNotFoundException;
import com.PgAccomodation.app.Repo.PgRepo;
import com.PgAccomodation.app.Repo.TenantRepository;
import com.PgAccomodation.app.Repo.UserRepository;
import com.PgAccomodation.app.dto.SuccessResponse;
import com.PgAccomodation.app.modal.Pg;
import com.PgAccomodation.app.modal.Tenant;
import com.PgAccomodation.app.modal.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TenantService {

    PgRepo pgRepo;
    UserRepository userRepository;
    TenantRepository tenantRepository;

    public TenantService(PgRepo pgRepo , UserRepository userRepository , TenantRepository tenantRepository){
        this.pgRepo = pgRepo;
        this.userRepository = userRepository;
        this.tenantRepository = tenantRepository;
    }

    public ResponseEntity<?> registerTenantToPg(String userId, String pgId) {
        try {

            Optional<User> userOptional = userRepository.findById(Integer.parseInt(userId));
            if (userOptional.isEmpty()) {
               throw new ResourceNotFoundException("User Not Found");
            }
            User user = userOptional.get();


            Optional<Pg> pgOptional = pgRepo.findById(Integer.parseInt(pgId));

            if (pgOptional.isEmpty()) {
                throw new ResourceNotFoundException("Pg Not Found");
            }
            Pg pg = pgOptional.get();


            if (pg.getAvailableSeats() <= 0) {
                throw new ResourceNotFoundException("PG full , No seats available");
            }


            Optional<Tenant> tenantOptional = tenantRepository.findByUser(user);
            Tenant tenant;

            if(tenantOptional.get().getPg() != null){
                throw new ResourceNotFoundException("User Already Registered To Pg");
            }

            if (tenantOptional.isPresent()) {
                tenant = tenantOptional.get();
                tenant.setPg(pg);
            } else {
                throw new ResourceNotFoundException("User Not Fund");
            }

            tenantRepository.save(tenant);

            pg.setAvailableSeats(pg.getAvailableSeats() - 1);
            pgRepo.save(pg);

            SuccessResponse<String> successResponse = new SuccessResponse<>(
                    HttpStatus.OK.value(),
                    "Hello " + user.getUsername(),
                    "User registered successfully to PG " + pg.getPgname()
            );

            return ResponseEntity.ok(successResponse);

        } catch (Exception e) {
            System.out.println(e);
            throw e;
        }
    }
}
