package com.PgAccomodation.app.dto;

public class PgDto {
    private int pgid;

    private String pgname;

    private String address;

    private String location;

    private int totalrooms;

    private int availableSeats;

    private int rentPerflat;

    public PgDto(int pgid, String pgname, String address, String location, int totalrooms, int availableSeats, int rentPerflat) {
        this.pgid = pgid;
        this.pgname = pgname;
        this.address = address;
        this.location = location;
        this.totalrooms = totalrooms;
        this.availableSeats = availableSeats;
        this.rentPerflat = rentPerflat;
    }

    public int getPgid() {
        return pgid;
    }

    public void setPgid(int pgid) {
        this.pgid = pgid;
    }

    public String getPgname() {
        return pgname;
    }

    public void setPgname(String pgname) {
        this.pgname = pgname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getTotalrooms() {
        return totalrooms;
    }

    public void setTotalrooms(int totalrooms) {
        this.totalrooms = totalrooms;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public int getRentPerflat() {
        return rentPerflat;
    }

    public void setRentPerflat(int rentPerflat) {
        this.rentPerflat = rentPerflat;
    }
}
