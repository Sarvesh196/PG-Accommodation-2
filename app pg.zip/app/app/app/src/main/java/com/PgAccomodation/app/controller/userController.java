package com.PgAccomodation.app.controller;

import com.PgAccomodation.app.dto.SuccessResponse;
import com.PgAccomodation.app.modal.User;
import com.PgAccomodation.app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class userController {

    @Autowired
    UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user){
        return userService.registerUser(user);
    }


    @GetMapping("/getUser")
    public ResponseEntity<?> getUser(){

        System.out.println("Inside Get User");

        SuccessResponse<String> successResponse = new SuccessResponse<>(
                HttpStatus.OK.value(),
                "Hello Prathamesh ",
                "This is your success data"
        );
        return new ResponseEntity<>(successResponse, HttpStatus.OK);
    }
}
