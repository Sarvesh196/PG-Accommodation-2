package com.PgAccomodation.app.dto;

import java.util.ArrayList;
import java.util.List;

public class RegisterPGResponseDto {

    private int pgid;
    private String pgname;
    private String address;
    private String location;
    private int totalrooms;
    private int availableSeats;
    private int rentPerflat;
    private OwnerDTO owner;
    private List<PgDto> pgs = new ArrayList();


    public int getPgid() {
        return pgid;
    }

    public RegisterPGResponseDto(int pgid, String pgname, String address, String location, int totalrooms, int availableSeats, int rentPerflat, OwnerDTO ownerDTO, List<PgDto> pgs) {
        this.pgid = pgid;
        this.pgname = pgname;
        this.address = address;
        this.location = location;
        this.totalrooms = totalrooms;
        this.availableSeats = availableSeats;
        this.rentPerflat = rentPerflat;
        this.owner = ownerDTO;
        this.pgs = pgs;
    }

    public void setPgid(int pgid) {
        this.pgid = pgid;
    }

    public String getPgname() {
        return pgname;
    }

    public void setPgname(String pgname) {
        this.pgname = pgname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getTotalrooms() {
        return totalrooms;
    }

    public void setTotalrooms(int totalrooms) {
        this.totalrooms = totalrooms;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public int getRentPerflat() {
        return rentPerflat;
    }

    public void setRentPerflat(int rentPerflat) {
        this.rentPerflat = rentPerflat;
    }

    public OwnerDTO getOwnerDTO() {
        return owner;
    }

    public void setOwnerDTO(OwnerDTO ownerDTO) {
        this.owner = ownerDTO;
    }

    public List<PgDto> getPgs() {
        return pgs;
    }

    public void setPgs(List<PgDto> pgs) {
        this.pgs = pgs;
    }
}
