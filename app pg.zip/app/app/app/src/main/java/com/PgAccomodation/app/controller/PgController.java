package com.PgAccomodation.app.controller;

import com.PgAccomodation.app.modal.Pg;
import com.PgAccomodation.app.service.PgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pg")
public class PgController {

    @Autowired
    PgService pgService;


    @PostMapping("/register-pg")
    public ResponseEntity<?> registerPg(@RequestBody Pg pg) {
        return pgService.registerPg(pg);
    }

    @GetMapping("/getPgByCity/{cityName}")
    public ResponseEntity<?> getPgByCity(@PathVariable("cityName") String cityName) {
        return pgService.getPgByCityName(cityName);
    }

    @GetMapping("/getPgById/{id}")
    public ResponseEntity<?> getPgById(@PathVariable("id") int pgId) {
        return pgService.getPgById(pgId);
    }

    @GetMapping("/getPgByLocality/{locality}")
    public ResponseEntity<?> getPgByLocality(@PathVariable("locality") String locality) {
        return pgService.getPgByLocality(locality);
    }

    @GetMapping("/getAllPgDetailsByOwner/{id}")
    public ResponseEntity<?> getAllPgDetailsByOwner(@PathVariable("id") int OwnerId){
        return pgService.getAllPgDetailsByOwner(OwnerId);
    }

    @GetMapping("/getPgOwnerDetails/{id}")
    public ResponseEntity<?> getPgOwnerDeails(@PathVariable("id") int pgId) {
        return pgService.getPgOwnerDetails(pgId);
    }

    @PutMapping("/updatePgDetails/{id}")
    public ResponseEntity<?> updatePgInfo(@PathVariable("id") int id, @RequestBody Pg pg) {
        return pgService.updatePgDetails(id, pg);
    }

    @DeleteMapping("/deletePgDetails/{id}")
    public ResponseEntity<?> deletePgInfo(@PathVariable("id") int id) {
        return pgService.deletePgDetails(id);
    }
}
