package com.PgAccomodation.app.Repo;

import com.PgAccomodation.app.modal.Owner;
import com.PgAccomodation.app.modal.Pg;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PgRepo extends JpaRepository<Pg , Integer> {
    Optional<Pg> findByPgnameAndOwner(String pgname, Owner owner);
    Optional<Pg> findByAddressAndOwner(String address, Owner owner);
    List<Pg> findByLocationIgnoreCase(String location);

}
