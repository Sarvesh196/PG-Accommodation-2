package com.PgAccomodation.app.Exception;

public class ResouceAlreadyExistException  extends RuntimeException{
    public ResouceAlreadyExistException(String message){
        super(message);
    }
}
